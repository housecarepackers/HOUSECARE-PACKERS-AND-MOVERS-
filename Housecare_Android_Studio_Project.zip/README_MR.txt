HOUSECARE PACKERS & MOVERS — ANDROID APK PROJECT

महत्त्वाचे: हा Android Studio project आहे; तयार APK नाही. या वातावरणात Android SDK/Gradle उपलब्ध नसल्यामुळे APK compile करता आलेला नाही.

APK तयार करण्याची पद्धत:
1. संगणकावर Android Studio install करा.
2. हा ZIP extract करा.
3. Android Studio > Open > extract केलेला HousecareAndroid folder निवडा.
4. Gradle Sync पूर्ण होऊ द्या. SDK 35 install करण्यास सांगितल्यास install करा.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
6. Build पूर्ण झाल्यावर app/build/outputs/apk/debug/app-debug.apk येथे APK मिळेल.
7. APK मोबाईलमध्ये पाठवा आणि उघडून Install करा. गरज पडल्यास Settings मध्ये त्या फाइल मॅनेजरसाठी "Install unknown apps" परवानगी द्या.

टीप:
- WhatsApp वर पाठवताना फोन नंबर country code सह टाका (भारतासाठी 91...).
- Job माहिती फोनमधील app storage मध्ये सेव्ह होते; फोन बदलल्यास/डेटा clear केल्यास हरवू शकते.
- हा पहिला बेसिक बिल्ड आहे. सार्वजनिक वितरणासाठी release signing, privacy/backup आणि चाचणी आवश्यक आहे.
